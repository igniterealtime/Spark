
How to build:

in terminal run:

ant build